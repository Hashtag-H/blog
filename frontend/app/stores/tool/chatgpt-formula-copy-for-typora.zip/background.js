const MENU_ID = "copy-for-typora";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_ID,
    title: "复制为 Typora Markdown",
    contexts: ["selection"],
    documentUrlPatterns: ["https://chatgpt.com/*", "https://chat.openai.com/*"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== MENU_ID || !tab?.id) return;
  sendCopyRequest(tab.id);
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== MENU_ID) return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) sendCopyRequest(tab.id);
});

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type !== "popup-copy-for-typora" || !sender.tab?.id) return;
  sendCopyRequest(sender.tab.id);
});

async function sendCopyRequest(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "copy-for-typora" });
  } catch {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content.js"]
    });
    await chrome.tabs.sendMessage(tabId, { type: "copy-for-typora" });
  }
}
